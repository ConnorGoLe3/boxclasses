﻿namespace PudelkoLibrary
{
    public enum UnitOfMeasure
    {
        meter = 1,
        centimeter = 100,
        milimeter = 1000
    }
}
